"""Registry med lazy import og try/except for distributions"""

_REGISTRY = {}
_FORBIDDEN = set()

def register(name, forbidden=False, category=None):
    def decorator(func):
        _REGISTRY[name] = func
        if forbidden:
            _FORBIDDEN.add(name)
        return func
    return decorator

def build_context():
    return _REGISTRY.copy(), _FORBIDDEN.copy()

# Importér calculus & statistics først (de virker altid)
from . import calculus
from . import statistics

# Registrer calculus
_REGISTRY['diff'] = calculus.diff
_FORBIDDEN.add('diff')
_REGISTRY['integrate'] = calculus.integrate_cas
_FORBIDDEN.add('integrate')
_REGISTRY['limit'] = calculus.limit
_FORBIDDEN.add('limit')
_REGISTRY['arclength'] = calculus.arclength
_FORBIDDEN.add('arclength')

# Registrer statistics
_REGISTRY['mean'] = statistics.mean
_FORBIDDEN.add('mean')
_REGISTRY['median'] = statistics.median
_REGISTRY['Q1'] = statistics.Q1
_REGISTRY['Q3'] = statistics.Q3
_REGISTRY['min'] = statistics.min_func
_FORBIDDEN.add('min')
_REGISTRY['max'] = statistics.max_func
_FORBIDDEN.add('max')
_REGISTRY['linReg'] = statistics.linReg
_FORBIDDEN.add('linReg')
_REGISTRY['expReg'] = statistics.expReg
_FORBIDDEN.add('expReg')
_REGISTRY['powReg'] = statistics.powReg
_FORBIDDEN.add('powReg')
_REGISTRY['logReg'] = statistics.logReg
_FORBIDDEN.add('logReg')

# Lazy import distributions - hvis den fejler, fortsætter vi
try:
    from . import distributions
    
    _REGISTRY['binompdf'] = distributions.binompdf
    _FORBIDDEN.add('binompdf')
    _REGISTRY['binomcdf'] = distributions.binomcdf
    _FORBIDDEN.add('binomcdf')
    _REGISTRY['poissonpdf'] = distributions.poissonpdf
    _FORBIDDEN.add('poissonpdf')
    _REGISTRY['poissoncdf'] = distributions.poissoncdf
    _FORBIDDEN.add('poissoncdf')
    _REGISTRY['normpdf'] = distributions.normpdf
    _FORBIDDEN.add('normpdf')
    _REGISTRY['normcdf'] = distributions.normcdf
    _FORBIDDEN.add('normcdf')
    _REGISTRY['invnorm'] = distributions.invnorm
    _FORBIDDEN.add('invnorm')
    _REGISTRY['mean_B'] = distributions.mean_B
    _FORBIDDEN.add('mean_B')
    _REGISTRY['var_B'] = distributions.var_B
    _FORBIDDEN.add('var_B')
    _REGISTRY['std_B'] = distributions.std_B
    _FORBIDDEN.add('std_B')
    _REGISTRY['mean_Po'] = distributions.mean_Po
    _FORBIDDEN.add('mean_Po')
    _REGISTRY['var_Po'] = distributions.var_Po
    _FORBIDDEN.add('var_Po')
    _REGISTRY['std_Po'] = distributions.std_Po
    _FORBIDDEN.add('std_Po')
    _REGISTRY['mean_N'] = distributions.mean_N
    _FORBIDDEN.add('mean_N')
    _REGISTRY['var_N'] = distributions.var_N
    _FORBIDDEN.add('var_N')
    _REGISTRY['std_N'] = distributions.std_N
    _FORBIDDEN.add('std_N')
    
except ModuleNotFoundError:
    # distributions.py blev ikke loaded - det er OK, fortsætter uden det
    pass
