/** P0021 Slice 61 — opt-in orchestration, never document authority.
 * Only authoritative edits enqueue work. A stale outcome is terminal for that
 * attempt: it never schedules another evaluation by itself.
 */
export function createSemanticAutoScheduler({runtime, createEvaluate, enqueue = queueMicrotask,
    onOutcome = () => {}, onError = () => {}} = {}) {
    if (!runtime || typeof runtime.subscribeSemanticChanges !== 'function' ||
        typeof runtime.evaluateAndCommitDirtySemanticTask !== 'function' ||
        typeof createEvaluate !== 'function' || typeof enqueue !== 'function' ||
        typeof onOutcome !== 'function' || typeof onError !== 'function') {
        throw new TypeError('semantic scheduler requires DocumentRuntime and callbacks');
    }
    const pending = new Set();
    let queued = false;
    let closed = false;
    let revisionCounter = 0;
    // A revision is an invocation token, not a second document generation.
    // DocumentRuntime remains the authority for source and block generations.
    const activeRevisions = new Map();
    const request = taskId => {
        if (closed) return;
        if (typeof taskId !== 'string' || !taskId) throw new TypeError('taskId required');
        pending.add(taskId);
        if (queued) return;
        queued = true;
        enqueue(() => {
            queued = false;
            if (closed) return;
            const tasks = [...pending];
            pending.clear();
            for (const task of tasks) {
                const revision = `semantic-auto-${++revisionCounter}`;
                activeRevisions.set(task, revision);
                Promise.resolve().then(() => runtime.evaluateAndCommitDirtySemanticTask(task, {
                    revision,
                    getCurrentRevision: () => activeRevisions.get(task),
                    createEvaluate: args => createEvaluate({...args, taskId: task}),
                })).then(result => onOutcome(task, result), error => onError(task, error));
            }
        });
    };
    const unsubscribe = runtime.subscribeSemanticChanges(taskIds => {
        for (const taskId of taskIds) request(taskId);
    });
    return Object.freeze({request, dispose() {closed = true; pending.clear(); unsubscribe();}});
}
