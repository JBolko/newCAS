/** P0021 Slice 70 — bounded repository consumer inventory and P0004 drift evidence. */
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {resolve,relative,extname} from 'node:path';
import {fileURLToPath} from 'node:url';

const root=resolve(fileURLToPath(new URL('../..',import.meta.url)));
const legacy=[
 'create-source-integer-assignment-task-evaluator.js',
 'create-source-literal-function-task-evaluator.js',
 'create-source-variable-function-task-evaluator.js',
 'create-source-expression-task-evaluator.js',
 'create-bound-function-task-evaluator.js',
];
const read=path=>readFileSync(resolve(root,path),'utf8');
function sources(dir){
 const out=[];
 function visit(d){
  for(const e of readdirSync(resolve(root,d),{withFileTypes:true})){
   const path=`${d}/${e.name}`;
   if(e.isDirectory())visit(path);
   else if(['.js','.mjs','.cjs'].includes(extname(path)))out.push(path);
  }
 }
 visit(dir); return out;
}
const importsOf=(code)=>[...code.matchAll(/\b(?:import|export)\s+(?:[\s\S]*?\s+from\s*)?['"](\.[^'"]+)['"]/g)].map(m=>m[1].split('?')[0]);
function directConsumers(){
 const results=[];
 for(const path of [...sources('src/js'),...sources('tests/js'),...sources('tests/browser')]){
  const code=read(path);
  for(const imp of importsOf(code)){
   const target=resolve(root,path,'..',imp);
   if(legacy.some(file=>target.endsWith(`/semantics/${file}`)))results.push({path,target:relative(root,target).replaceAll('\\','/')});
  }
 }
 return results;
}

test('production imports none of the five historical evaluator adapters',()=>{
 const production=directConsumers().filter(x=>x.path.startsWith('src/js/'));
 assert.deepEqual(production,[],`unexpected production consumers: ${JSON.stringify(production)}`);
});
test('historical direct consumers are explicitly confined to contract and browser tests',()=>{
 const users=directConsumers();
 assert.ok(users.some(x=>x.path.startsWith('tests/js/')),'missing unit-level migration witnesses');
 assert.ok(users.some(x=>x.path.startsWith('tests/browser/')),'missing browser migration witness');
 assert.ok(users.every(x=>x.path.startsWith('tests/js/')||x.path.startsWith('tests/browser/')));
 assert.ok(users.every(x=>legacy.some(name=>x.target.endsWith(name))));
});
test('active production batch is outside the direct legacy import set',()=>{
 assert.ok(!directConsumers().some(x=>x.path.endsWith('create-runtime-function-batch-evaluator.js')));
 const batch=read('src/js/semantics/create-runtime-function-batch-evaluator.js');
 assert.match(batch,/createSourceComposedExpressionTaskEvaluator/);
 assert.match(batch,/createSourceFunctionDefinitionTaskEvaluator/);
});
test('P0004 selected backend and Worker version mismatch remains visible as an open migration gap',()=>{
 const policy=read('docs/architecture/P0004-version-lock-and-developer-baseline.md');
 const worker=read('src/js/evaluation/selected-pyodide-worker.js');
 const oldApp=read('src/js/cas-engine.js');
 assert.match(policy,/Pyodide\s+314\.0\.7/);
 assert.match(policy,/SymPy\s+1\.14\.0/);
 assert.match(worker,/pyodide\/v0\.26\.1\/full/);
 assert.match(oldApp,/pyodide\/v0\.26\.1\/full/);
 // This is characterization, NOT an assertion that the new Worker is compliant.
 // Remove/replace this test with a RED->GREEN actual Worker integration check
 // when migrating the Worker to the P0004 backend.
 assert.notEqual('314.0.7','0.26.1');
});
